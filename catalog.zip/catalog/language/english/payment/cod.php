<?php
// Text
$_['text_title'] = 'Cash On Delivery';
?>